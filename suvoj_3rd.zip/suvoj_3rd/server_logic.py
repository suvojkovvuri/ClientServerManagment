import os
class Serverlogic:

    """
       This class contains all the operations done by the server i.e the
       all the function definitions related to the commands
    """

    def __init__(self, username, pass1, currDir, rootDir):

        """__init__ [initializing the attributes]


        Arguments:

            username {[str]} -- [gets the username from the client]

            pass1 {[str]} -- [getting the pass1 from the client]

            currDir {[str]} -- [getting the current directory from the client]

            rootDir {[str]} -- [getting the rootDir from the client]

        """
        self.username = username
        self.pass1 = pass1
        self.currDir = currDir
        self.rootDir = rootDir
        self.read_file = " "
        self.fp = 0

    def input_file(self, filename, data, input_data):

        """input_file [This fuction ]

        Arguments:

            filename {[type]} -- [description]

            data {[type]} -- [description]

            input_data {[type]} -- [description]

        """
        filedata = str(f'{data}\\{filename}')
        fileinfo = open(filedata, 'a')
        user_data = [input_data, "\n"]
        fileinfo.writelines(user_data)
        fileinfo.close()
    def folder_create(self, filename):

        """folder_create [creates a folder with usernam]



        Arguments:

            filename {[str]} -- [takes folder name for the user]



        Returns:

            [str] -- [returns message if the file is created or not]

        """
        try:
            file_path = os.path.join(self.currDir, filename)
            os.mkdir(file_path)
        except IOError:
            return 'failed in creation of folder'
        return 'folder created successfully'

    def file_read(self, filename):

        """file_read [Reading the file]



        Arguments:

            filename {[str]} -- [takes the filename to read]



        Returns:

            [str] -- [returns the string message if the given statements are passed ]

        """
        if filename is None:
            if self.read_file != '':
                self.read_file = ''
                return 'file  is closed'
            return 'wrong argument'
        file_path = os.path.join(self.currDir, filename)
        try:
            if os.path.exists(file_path):
                if self.read_file == filename:
                    self.fp += 100
                    return self.location_of_file(file_path, self.fp)

                self.read_file = filename
                self.fp = 0
                return self.location_of_file(file_path, self.fp)
            return 'no such file exist'
        except FileNotFoundError:
            return 'given file is a folder'

    def write_file(self, filename, msg = None):

        """write_file [writing the file or editing the file]



        Arguments:

            filename {[type]} -- [description]



        Keyword Arguments:

            msg {[str]} -- [takes the data to write/edit the file] (default: {None})



        Returns:

            [str] -- [returns the string message if the file is edited/wrote ]

        """
        file_path = os.path.join(self.currDir, filename)
        if msg != None:
             with open(file_path, 'a') as file1:
                info = [msg, '\n']
                file1.writelines(info)
                file1.close()
                return 'file edited'
        else:
            with open(file_path, 'w') as file2:
                file2.close()
                return 'file cleared'

    def list_of_files(self):

        """list_of_files [this function is used for retreving the list of the file]



        Returns:

            [list] -- [getting the list of file]

        """
        list_dir = os.listdir(os.getcwd())
        for i1 in range(len(list_dir)):
            print(list_dir[i1])
        return list_dir

    def location_of_file(self, filename, fp):

        """location_of_file [Thus function reads the first 100 lines of the file]

        Arguments:

            filename {[str]} -- [filename to read the first 100 lines]

            fp {[int]} -- [store the first 100 libes of information]

        """
        start = fp+100
        fileopen = open(filename, 'r')
        res = fileopen.read()
        if start >= len(res):
            self.fp = 0
        return str(res[fp:start])

    def user_list (self, dir):

        """user_list [This writes the userlog.txt file which is used to append the username into the file]

        """
        file_list = str(f'{dir}\\log.txt')
        userfile = open(file_list, 'w')
        info = self.username
        userdata = [info, '/n']
        userfile.writelines(userdata)
        userfile.close()

    def changing_folder(self, filename):

        """changing_folder [This function changes the folder path ]

        """
        fpath = (self.rootDir)[::-1]
        searchslash = fpath.find('\\')+1
        final = fpath[searchslash:][::-1]
        try:
            if filename == '..':
                reverse = (self.currDir)[::-1]
                searchslash1 = reverse.find('\\')+1
                path = reverse[searchslash1:][::-1]
                if path == final:
                    return 'Access denied'
                self.currDir = (path)
                return 'directory changed to : '+self.currDir
            dir = os.path.join(self.currDir, filename)
            if os.path.isdir(dir):
                if self.currDir == self.rootDir:
                    if filename == self.username:
                        self.currDir = dir
                        return 'directory changed to : '+self.currDir
                    else:
                        return 'Access denied'
                self.currDir = dir
                return 'directory changed to : '+self.currDir
            else:
                return 'File not found'
        except Exception as err:
            return err













