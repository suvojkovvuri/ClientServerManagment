import asyncio
import signal
from server import server_method
signal.signal(signal.SIGINT, signal.SIG_DFL)
DICTIONARY = {}
portnum = 9999
conclose = "connection closed"
ipaddress = '127.0.0.1'
async def server_file(duelist, controller):
    """server_file [connection for the client]
    """
    server_name = controller.get_extra_info('peername')
    send_msg = f"{server_name} connection established."
    DICTIONARY[server_name[1]] = server_method()
    while True:
        info = await duelist.read(10000)
        send_msg = info.decode().strip()
        if send_msg == 'quit':
            DICTIONARY[server_name[1]].deleteUser()
            break
        print(f"Received {send_msg} from {server_name}")
        response = DICTIONARY[server_name[1]].print_msg(send_msg)
        print(f"Send: {response}")
        if (response != 'None') or (response != ''):
            controller.write(response.encode())
        else:
            response = '.'
            controller.write(response.encode())
        await controller.drain()
    print(conclose)
    controller.close()

def logs():
    logfile = open('loginlog.txt', 'w')
    logfile.close()

async def main():
    """main [main function]
    """
    logs()
    server = await asyncio.start_server(
        server_file, ipaddress, portnum)
    # server_info = server.sockets[0].getsockname()
    print(f'Serving {server}')
    async with server:
        await server.serve_forever()
asyncio.run(main())
