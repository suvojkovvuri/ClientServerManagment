import os
from server_logic import Serverlogic

class server_method:
    def __init__(self):
        """__init__ [initializing variables]
        """
        self.username = ''
        self.password = ''
        self.rootDir = os.getcwd()
        self.currDir = ''
        self.msg = ''
    def checking_user(self, username):
        """checking_user [user is being verified here]

        Arguments:
            username {[string]} -- [this describes the username argument type]

        Returns:
            [string] -- [username]
        """
        logfile = 'userlog.txt'
        filename = str(f'{self.rootDir}\\{logfile}')
        with open(filename, 'r') as r_file:
            read_lines = r_file.readlines()
            sum_line = sum(1 for everyline in read_lines)
            rar = 0
            numberlist = []
            namelist = []
            for rar in range(sum_line):
                file = read_lines[rar].strip()
                com = file.find(',')
                numberlist.append(com)
                namelist.append(file[:numberlist[rar]])
            if username in namelist:
                return 'exist'
            return 'error occured'
    def deleteUser(self):
        """deleteUser [username is deleted here]
        """
        pathfile = os.path.join(self.rootDir, 'loginlog.txt')
        with open(pathfile, 'r') as nfile:
            rlines = nfile.readlines()
            for i in range(len(rlines)):
                if self.username in rlines[i]:
                    pos = i
        nfile.close()
        nfile = open(pathfile, 'w')
        for i in range(len(rlines)):
            if pos != i:
                nfile.writelines(rlines[i])
        nfile.close()
    def authenticatePassword(self, username):
        """authenticatePassword [here the password is checked]

        Arguments:
            username {[string]} -- [username argument is given here]

        Returns:
            [string] -- [username]
        """
        ufile = open('userlog.txt', 'r')
        pwd_read = ufile.readlines()
        names_list = []
        pwd_list = []
        for i in pwd_read:
            file_split = i.strip().split(",", 1)
            names_list.append(file_split[0])
            pwd_list.append(file_split[1])
        for j in range(0, len(names_list)):
            if username == names_list[j]:
                creds = pwd_list[j]
                return creds
        return 'failed'
    def edit_file(self, data, filename, input_data):
        """edit_file [editing the file is done here]

        Arguments:
            data {[list]} -- [list is created]
            filename {[string]} -- [filename argument is given here]
            input_data {[string]} -- [input data argument is given here]
        """
        filename = str(f'{data}\\{filename}')
        input_data = input_data
        with open(filename, 'a+') as edit_file:
            data = [input_data, '\n']
            edit_file.writelines(data)
            edit_file.close()
    def registration(self, username, password):
        """registration [users are added in a text file here]

        Arguments:
            username {[string]} -- [takes username]
            password {[string]} -- [takes password]
        """
        path = str(f'{self.rootDir}\\userlog.txt')
        with open(path, 'a+') as register_user:
            data = str(f'{username},{password}\n')
            register_user.writelines(data)
            register_user.close()
            self.create_folder(username)

    def create_folder(self, username):
        """create_folder [Here a new folder is created]

        Arguments:
            username {[string]} -- [username is the arguments here]
        """
        npath = os.path.join(self.rootDir, username)
        os.mkdir(npath)
        self.logs(npath, username)
    def print_msg(self, msg):
        """print_msg [printing a message is done here]

        Arguments:
            msg {[list]} -- [a list is created here]

        Returns:
            [list] -- [message]
        """
        self.msg = msg
        msg = self.msg.split(' ', 2)
        print('message: ', msg)
        reply = self.messages(msg)
        print('message reply: ', reply)
        return reply
    def userRegistration(self):
        """userRegistration [checks whether the user is registered or not ]
        Returns:
            [string] -- [returns the login information]
        """
        msg = self.msg.split(' ', 3)
        username = msg[1]
        password = msg[2]
        rep = self.checking_user(username)
        try:
            if rep == 'exist':
                return rep
        except NameError as nameerror:
            return nameerror
        self.registration(username, password)

        msg = ['login', username, password]
        res = self.login_user(msg)
        return res
    def send_data(self):
        """send_data [calling the properties of logic class]
        """
        self.client = Serverlogic(
            self.username,
            self.password,
            self.currDir,
            self.rootDir)
    def messages(self, msg):
        """messages [handling the messages from client ]
        """
        cmd = msg[0]
        if self.username == '':
            if cmd == "login":
                try:
                    res = self.login_user(msg)
                except IOError as ie:
                    res = 'error occured while login'
                return res
            if cmd == 'register':
                try:
                    res = self.userRegistration()
                    # print("hi")
                except IOError:
                    res = 'error occured while registering'
                return res
        elif cmd == 'create_folder':
            try:
                folder_name = msg[1]
                res = self.client.folder_create(folder_name)
            except IOError:
                res = 'error occured while creation of folder'
            return res
        elif cmd == "list":
            res = self.client.list_of_files()
            if res is not None:
                rep = 'files created successfully' 
            else:
                rep = 'error occured'
            return rep
        elif cmd == "change_folder":
            try:
                res = self.client.changing_folder(msg[1])
            except Exception:
                res = 'error occured while modyfying the directory'
            return res
        elif cmd == "read_file":

            try:
                res = self.client.file_read(msg[1])
            except Exception:
                res = 'error occured while reading the file'
            return res
        elif cmd == 'write_file':
            try:
                bucket = msg[1]
            except IndexError:
                rep = 'invalid Argument'
                return rep
            try:
                data = msg[2]
                rep = self.client.write_file(bucket, data)
            except IndexError:
                rep = self.client.write_file(bucket)
            except Exception:
                rep = 'error occured while modyfying the file'
            return rep
        else:
            return "Input is inavlid"

    def login_user(self, msg):
        """login_user [checks whether the user is logged in or not.]

        Arguments:
            msg {[list]} -- [list of messages]

        Returns:
            [string] -- [returns the message if given comments are passed]
        """
        username = msg[1]
        login_info = open('loginlog.txt', 'r')
        file = login_info.read()
        if username in file:
            return "   user loggedin"
        pwd = msg[2]
        reply = self.authenticatePassword(username)
        if reply == 'failed':
            return 'failedcheck'
        try:
            if reply == pwd:
                directory = os.path.join(self.rootDir, username)
                self.currDir = directory
                self.username = username
                self.password = pwd
                self.send_data()
                print('initiate')
                self.edit_file(self.rootDir,
                                  'loginlog.txt', self.username)
                return'sucessfull'
            else:
                return 'failedpwd'
        except:
            return 'failedpwd22'

    def logs(self, user_dir, username):
        """logs [writes the userlog.txt file.]
        """
        filedata = str(f'{user_dir}\\log.txt')
        with open(filedata, 'w') as userlogs:
            info = username
            logs_list = [info, "\n"]
            userlogs.writelines(logs_list)
            userlogs.close()





