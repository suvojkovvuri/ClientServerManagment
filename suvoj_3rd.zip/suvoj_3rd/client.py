import asyncio

TECH = ''
errorMessage = 'Error occured, try Again'
   

def start_server():
    """start_server [Starting the server]
    """
    print("server for file management")
    while True:
        print('1.register')
        print('2.login')
        option = input('Select an option(1,2): ')
        if option == '1':
            result = client_registration()
            return result
        elif option == '2':
            result = client_login()
            return result
        print('Invalid Input')
def len1():
    with open('commands.txt', 'r') as help_file:
        helpcmd = help_file.read()
        print(helpcmd)
        return False

def reply_messages(message):
    """reply_messages [checks the given statements are passed or not from server ]
    Arguments:
        message {[str]} -- [handles the messages from the server]
    Returns:
        [Bool] -- [returns True if the given statements are passed]
    """
    message1 = message.split(' ', 2)
    cmd = message1[0]
    message_len = len(message1)
    global TECH
    if cmd == 'commands':
        if message_len == 1:
            len1()
        elif message_len == 2:
            comnt = message1[1]
            if comnt == 'issued':
                print(TECH)
                return False
            elif comnt == 'clear':
                TECH = ''
                print('Cleared')
                return False
            print('Invalid command')
            return False
        print('invalid arguments')
        return False
    TECH += str('\n'+message)
    return True
def username_pass1():
	username = input('Enter Username ')
	pass1 = input('Enter Password ')
	return username,pass1

def client_registration():
    """client_registration [Taking the username and pass1 from the user]

    Returns:
        [str] -- [returns username and pass1]
    """
    print('Welcome to the registration page.')
    username,pass1 = username_pass1()
    rep = str(f'register {username} {pass1}')
    return rep

def client_login():
    """client_login [taking the user responses making ser to login]

    Returns:
        [str] -- [returns the username and pass1 ]
    """
    print('Welcome to the login page')
    username,pass1 = username_pass1()
    rep = str(f'login {username} {pass1}')
    return rep
def mesg1():
    print('Error occured while login ')
    print('Try Again')

def successmesg():
    print('successfully logged in ')

def exitmesg():
    print('User has already logged in ')
    print('Try again with new Username ')

async def client_acknolegment():
    """client_acknolegment [handles the operations from server]
    """
    duelist, controller = await asyncio.open_connection('127.0.0.1', 9999)
    message = ''
    while 1:
        con = start_server()
        controller.write(con.encode())
        wait = await duelist.read(10000)
        message = wait.decode()
        if message == 'sucessfull':
            successmesg()
            break
        elif message == 'Created':
            print('New user Created')
            break
        elif message == 'exist':
            exitmesg()
            continue
        elif message == 'failed':
            mesg1()
            continue
        elif message == 'invalid':
            print('provide correct input')
            continue
        elif message == '     user loggedin':
            print('Same user logged in from another client')
            continue
        else:
            print(errorMessage)
            continue
    while 1:
        message = input('>>>')
        if message == 'quit':
            controller.write(message.encode())
            break
        elif message == '':
            continue
        res = reply_messages(message)
        if res:
            controller.write(message.encode())
            pause = await duelist.read(10000)
            print(f'{pause.decode()}')
    print('connection has been terminated')
    controller.close()

try:
    asyncio.run(client_acknolegment())
except ConnectionRefusedError as error:
    print(error)

