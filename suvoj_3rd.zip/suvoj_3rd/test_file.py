import os
import unittest
from server_logic import Serverlogic

class testing_logic(unittest.TestCase):
    """testing_logic [Thins functionis to test the given methods]

    Arguments:
        unittest {[module]} -- [This module is used for testing the code]
    """
    def testing_file(self):
        """testing_file [Testing the write file if the file is not present creates the file and writes the file]
        """
        path = Serverlogic(os.getcwd(), os.getcwd(), 'suvoj', 'suvoj')
        testcases = [['testfile.txt', 'hello'],
                       ['testfile.txt', 'stmnt']]
        returncases = ['file edited', 'file edited']
        result = []
        for case in testcases:
            result.append(path.write_file(case[0], case[1]))
        self.assertListEqual(result, returncases)
    def test_readfile(self):
        """test_readfile [Testing the read file]
        """
        path = Serverlogic(os.getcwd(), os.getcwd(), 'suvoj', 'suvoj')
        testcases = ['duck1', 'duck1']
        outputvalues = ['folder created successfully', 'failed to create folder']
        test_list = []
        for r_file in testcases:
            test_list.append(path.folder_create(r_file))
        self.assertListEqual(test_list, outputvalues)
    def test_listoffiles(self):
        """test_listoffiles [testing list of files]
        """
        path = Serverlogic(os.getcwd(), os.getcwd(), 'suvoj', 'suvoj')
        outputvalues = [['client.py','commands.txt','instructions.txt','loginlog.txt',
        'suvoj','server.py','server_logic.py','server_main.py','test_file.py','userlog.txt','__pycache__']]
        test_list = []
        test_list.append(path.list_of_files())
        print(test_list)
        self.assertListEqual(test_list,outputvalues)
    def test_foldercreate(self):
        """test_foldercreate [testing creation of folders]
        """
        path = Serverlogic(os.getcwd(), os.getcwd(), 'suvoj', 'suvoj')
        testcases = ["suvoj"]
        outputvalues = ['folder created successfully']
        outputvalues1 = ['failed in creation of folder']
        test_list = []
        for r_file in testcases:
            test_list.append(path.folder_create(r_file))
        if test_list[0] == "folder created successfully":
            self.assertListEqual(test_list,outputvalues)
        else:
            self.assertEqual(test_list,outputvalues1)
if __name__ == '__main__':
    unittest.main()